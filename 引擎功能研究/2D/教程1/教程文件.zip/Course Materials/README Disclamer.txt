Some of the given assets belong to Nexon Corporation https://www.nexon.com.

- The given assets may not be redistributed to Steam, Epic Games Store, or any other platform.
- The assets may only be used for educational purposes in Unreal Engine 5.

If you want to release a game with this course, please use your own custom or other free assets.

Thank you so much for supporting me, and you're welcome to connect with me on social media to chat or ask for help:

- Website: https://pixelhelmet.com/
- Discord: https://discord.io/PixelHelmet
- Twitter: https://twitter.com/PixelHelmet

Kind regards
Moustafa Nafei
CEO, Game Designer & Programmer @ Pixel Helmet